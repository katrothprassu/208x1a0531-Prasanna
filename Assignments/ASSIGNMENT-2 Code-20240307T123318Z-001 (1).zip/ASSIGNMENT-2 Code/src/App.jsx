

import './App.css'
import './card.css'
import { Input } from './components/input';


function App() {
  
  return (
    <div>
     <Input></Input>
    </div>
  )
}

export default App
