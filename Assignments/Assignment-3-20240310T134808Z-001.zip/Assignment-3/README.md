# Assignment 3
## Rest API with CRUD Operations on MongoDB
### To run the file
### Use Following Commands :
npm init <br/>
npm install express <br/>
node backend.js <br/>

Use postman or any API testing applications to perform CRUD operations. <br/>
Note :In mongodb.js file replace your key with your database key.
